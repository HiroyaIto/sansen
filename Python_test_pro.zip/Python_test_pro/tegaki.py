from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.utils import to_categorical# データセットのロード
(X_train, y_train), (X_test, y_test) = mnist.load_data()# データの前処理
X_train = X_train.reshape(60000, 28, 28, 1).astype(‘float32’) / 255
X_test = X_test.reshape(10000, 28, 28, 1).astype(‘float32′) / 255
y_train = to_categorical(y_train, 10)
y_test = to_categorical(y_test, 10)# モデルの構築
model = Sequential([
Flatten(input_shape=(28, 28)),
Dense(128, activation=’relu’),
Dense(10, activation=’softmax’)
])# モデルのコンパイル
model.compile(optimizer=’adam’, loss=’categorical_crossentropy’, metrics=[‘accuracy’])# モデルのトレーニング
model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=200)# モデルの評価
score = model.evaluate(X_test, y_test)
print(‘Test loss:’, score[0])
print(‘Test accuracy:’, score[1])