# scikit-learnをインポートする
from sklearn.datasets import fetch_openml
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# MNISTデータをダウンロード
mnist = fetch_openml('mnist_784', version=1)

# 全データを学習データとテストデータに分ける
X_train, X_test, y_train, y_test = train_test_split(mnist.data, mnist.target, random_state=0)

# サポートベクトルマシンモデルで学習
model = SVC()
model.fit(X_train, y_train)

# テストデータで予測
y_pred = model.predict(X_test)

# 正解率で機械学習モデルの精度を評価
print("予測精度:", accuracy_score(y_test, y_pred))